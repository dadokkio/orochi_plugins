# Author:    Edmund Hughes
# Github:    https://github.com/its-radio
#   Blog:    https://itsrad.io
#
# This plugin is partially based on code from the Volatility Framework's standard plugins,
# Copyright (c) 2020 Volatility Foundation.
# 
# Code from the Volatility Framework is licensed under the Volatility Software License 1.0,
# available at: https://www.volatilityfoundation.org/license/vsl-v1.0



import sqlite3
import logging
import os
import re
import inspect
from typing import List, Generator

from volatility3.framework import interfaces, renderers, exceptions, constants
from volatility3.framework.configuration import requirements
from volatility3.framework.renderers import format_hints, UnreadableValue
from volatility3.plugins.windows import pslist
from volatility3.plugins.windows import dumpfiles
from volatility3.plugins.windows import handles
from volatility3.cli import CommandLine

vollog = logging.getLogger(__name__)

FILE_DEVICE_DISK = 0x7
FILE_DEVICE_NETWORK_FILE_SYSTEM = 0x14
EXTENSION_CACHE_MAP = {
    "dat": "DataSectionObject",
    "img": "ImageSectionObject",
    "vacb": "SharedCacheMap",
}

TEMP_FILES_WRITTEN = []

class Chrome_Hx(interfaces.plugins.PluginInterface):
    """Extracts and parses Chrome browser history from memory dumps."""

    _required_framework_version = (2, 0, 0)
    _version = (1, 0, 0)

    @classmethod
    def get_requirements(cls) -> List[interfaces.configuration.RequirementInterface]:
        return [
            requirements.ModuleRequirement(
                name="kernel",
                description="Windows kernel",
                architectures=["Intel32", "Intel64"],
            ),
            requirements.IntRequirement(
                name="pid",
                description="Process ID to include (all other processes are excluded)",
                optional=True,
            ),
            requirements.StringRequirement(
                name="filter",
                description="Dump files matching regular expression FILTER",
                default="Chrome.*History$",
                optional=True,
            ),
            requirements.BooleanRequirement(
                name="ignore-case",
                description="Ignore case in filter match",
                default=False,
                optional=True,
            ),
            requirements.VersionRequirement(
                name="pslist", component=pslist.PsList, version=(2, 0, 0)
            ),
            requirements.VersionRequirement(
                name="dumpfiles", component=dumpfiles.DumpFiles, version=(1, 0, 0)
            ),
            requirements.VersionRequirement(
                name="handles", component=handles.Handles, version=(1, 0, 0)
            ),
        ]

    def _generator(self, procs):
        kernel = self.context.modules[self.config["kernel"]]
        file_re = None
        flags = re.I if self.config["ignore-case"] else 0
        file_re = re.compile(self.config["filter"], flags)
        
        # The handles plugin doesn't expose any staticmethod/classmethod, and it also requires stashing
        # private variables, so we need an instance (for now, anyway). We _could_ call Handles._generator()
        # to do some of the other work that is duplicated here, but then we'd need to parse the TreeGrid
        # results instead of just dealing with them as direct objects here.
        handles_plugin = handles.Handles(
            context=self.context, config_path=self._config_path
        )
        type_map = handles_plugin.get_type_map(
            context=self.context,
            layer_name=kernel.layer_name,
            symbol_table=kernel.symbol_table_name,
        )
        cookie = handles_plugin.find_cookie(
            context=self.context,
            layer_name=kernel.layer_name,
            symbol_table=kernel.symbol_table_name,
        )

        # a set of the paths of any files dumped
        dumped_files = set()

        # a list of dumped files to go over and yield info back to run()
        file_names_list = list()

        # find the output directory specified by the user
        output_dir = ''
        stack = inspect.stack()
        for frame_info in stack:
            frame = frame_info.frame
            if 'self' in frame.f_locals:
                instance = frame.f_locals['self']
                # Check if this is a CommandLine instance
                if isinstance(instance, CommandLine):
                    output_dir = instance.output_dir
                    location = instance.location_from_file
                    vollog.debug(f'Output dir specified as: {output_dir}')
                    break

        # make sure the output dir is usable for this plugin
        if not output_dir:
            output_dir = os.getcwd()
        else:
            # volatility won't run unless there is already valid input for -o
            output_dir = os.path.abspath(output_dir)

        for proc in procs:
            try:
                object_table = proc.ObjectTable
            except exceptions.InvalidAddressException:
                vollog.log(
                    constants.LOGLEVEL_VVV,
                    f"Cannot access _EPROCESS.ObjectTable at {proc.vol.offset:#x}",
                )
                continue

            for entry in handles_plugin.handles(object_table):
                try:
                    obj_type = entry.get_object_type(type_map, cookie)
                    if obj_type == "File":
                        file_obj = entry.Body.cast("_FILE_OBJECT")

                        if file_re:
                            name = file_obj.file_name_with_device()
                            #vollog.debug(f'dir(file_obj): {file_obj.FileName}')
                            #vollog.debug(f'dir(file_obj): {dir(file_obj.FileName)}')
                            if isinstance(name, UnreadableValue):
                                continue
                            if not file_re.search(name):
                                continue

                        if file_obj.vol.offset in dumped_files:
                            continue
                        dumped_files.add(file_obj.vol.offset)

                        for result in dumpfiles.DumpFiles.process_file_object(
                            self.context, kernel.layer_name, self.open, file_obj
                        ):
                            # add the relative paths of the written files to a list
                            file_names_list.append(result[-1])

                except exceptions.InvalidAddressException:
                    vollog.log(
                        constants.LOGLEVEL_VVV,
                        f"Cannot extract file from _OBJECT_HEADER at {entry.vol.offset:#x}",
                    )

        # a list of the full paths to written files
        full_paths_list = [os.path.join(output_dir, name) for name in file_names_list]

        # Process the dumped files with SQLite
        for file_path in full_paths_list:
            if file_path.endswith('.vacb'):
                try:
                    con = sqlite3.Connection(file_path)
                    cur = con.cursor()
                    res = cur.execute('SELECT * FROM urls;')
                    for item in res.fetchall():
                        yield(0, item)
                except sqlite3.Error as e:
                    vollog.warning(f"SQLite error processing {file_path}: {e}")

    def run(self):
        # a list of processes matching the pid filter. all files for these process(es) will be dumped.
        procs = list()
        kernel = self.context.modules[self.config["kernel"]]

        filter_func = pslist.PsList.create_pid_filter(
            [self.config.get("pid", None)]
        )
        procs = pslist.PsList.list_processes(
            self.context,
            kernel.layer_name,
            kernel.symbol_table_name,
            filter_func=filter_func,
        )

        return renderers.TreeGrid(
            [
                ("ID", int),
                ("URL", str),
                ("Title", str),
                ("Visit_Count", int),
                ("Typed_Count", int),
                ("Last_Visit_Time", int),
                ("Hidden", int),
            ],
            self._generator(procs),
        )
