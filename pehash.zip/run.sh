 apt install -y libffi-dev libfuzzy-dev libfuzzy2
